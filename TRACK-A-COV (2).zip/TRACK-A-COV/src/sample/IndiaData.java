package sample;

public class IndiaData {
}
